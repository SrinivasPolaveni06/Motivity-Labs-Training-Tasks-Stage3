import React from "react";

const index = () => {
  return <div>Welcome To Appliances Page</div>;
};

export default index;
