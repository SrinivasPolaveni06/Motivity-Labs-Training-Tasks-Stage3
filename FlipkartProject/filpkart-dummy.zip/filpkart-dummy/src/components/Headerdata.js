export const data = [
  {
    category: "Grocery",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/29327f40e9c4d26b.png?q=100",
    navigateUrl: "/grocerys",
  },
  {
    category: "Mobiles",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/22fddf3c7da4c4f4.png?q=100",
    navigateUrl: "/mobiles",
  },
  {
    category: "Fashion",
    imageUrl:
      "https://rukminim1.flixcart.com/fk-p-flap/128/128/image/0d75b34f7d8fbcb3.png?q=100",
    navigateUrl: "/fashion",
  },
  {
    category: "Electronics",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/69c6589653afdb9a.png?q=100",
    navigateUrl: "/electronics",
  },
  {
    category: "Home",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/ab7e2b022a4587dd.jpg?q=100",
    navigateUrl: "/homematerials",
  },
  {
    category: "Appliances",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/0ff199d1bd27eb98.png?q=100",
    navigateUrl: "/appliances",
  },
  {
    category: "Travel",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/71050627a56b4693.png?q=100",
    navigateUrl: "/travel",
  },
  {
    category: "Top Offers",
    imageUrl:
      "https://rukminim1.flixcart.com/flap/128/128/image/f15c02bfeb02d15d.png?q=100",
    navigateUrl: "/offers",
  },
  {
    category: "Two Wheelers",
    imageUrl:
      "https://rukminim1.flixcart.com/fk-p-flap/128/128/image/05d708653beff580.png?q=100",
    navigateUrl: "/vechiles",
  },
];

